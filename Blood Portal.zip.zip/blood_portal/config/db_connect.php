<?php
// Add :3307 to the host
$host = "localhost:3307";  // Changed from localhost
$user = "root";
$pass = "";
$dbname = "blood_portal_db";

$conn = new mysqli($host, $user, $pass, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$conn->set_charset("utf8mb4");
?>
<?php 
include 'config/db_connect.php';
include 'includes/header.php';

// Get all donors
$donors = $conn->query("SELECT * FROM donors WHERE availability = 'Available' ORDER BY created_at DESC");
?>

<section class="page-header" style="background: linear-gradient(135deg, var(--primary-color), var(--accent-color)); padding: 80px 0; color: white; text-align: center;">
    <div class="container">
        <h1>Our Donors</h1>
        <p>Meet the heroes who save lives every day</p>
    </div>
</section>

<section class="container" style="padding: 60px 20px;">
    <div class="section-title">
        <h2>Available Donors</h2>
        <p>These donors are ready to help in times of need</p>
    </div>
    
    <div class="stats-grid">
        <?php if ($donors && $donors->num_rows > 0): ?>
            <?php while($row = $donors->fetch_assoc()): ?>
                <div class="stat-card">
                    <div style="background: var(--secondary-color); width: 80px; height: 80px; border-radius: 50%; margin: 0 auto 20px; display: flex; align-items: center; justify-content: center;">
                        <span style="font-size: 2rem; color: var(--primary-color);"><?php echo $row['blood_group']; ?></span>
                    </div>
                    <h3><?php echo $row['name']; ?></h3>
                    <p><i class="fas fa-map-marker-alt"></i> <?php echo $row['city']; ?></p>
                    <p><i class="fas fa-phone"></i> <?php echo $row['phone']; ?></p>
                    <p><i class="fas fa-envelope"></i> <?php echo $row['email']; ?></p>
                    <p><i class="fas fa-check-circle"></i> <?php echo $row['availability']; ?></p>
                    <a href="mailto:<?php echo $row['email']; ?>" class="btn btn-primary" style="margin-top: 15px;">Contact</a>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <p style="text-align: center; grid-column: 1/-1;">No donors available at the moment.</p>
        <?php endif; ?>
    </div>
</section>

<?php include 'includes/footer.php'; ?>